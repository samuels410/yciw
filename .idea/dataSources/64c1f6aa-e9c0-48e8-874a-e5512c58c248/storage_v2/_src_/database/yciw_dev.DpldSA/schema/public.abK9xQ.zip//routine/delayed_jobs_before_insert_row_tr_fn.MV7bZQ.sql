create function delayed_jobs_before_insert_row_tr_fn() returns trigger
    SET search_path = public
    language plpgsql
as
$$
BEGIN
        IF NEW.strand IS NOT NULL THEN
          PERFORM pg_advisory_xact_lock(half_md5_as_bigint(NEW.strand));
          IF (SELECT COUNT(*) FROM (
              SELECT 1 AS one FROM delayed_jobs WHERE strand = NEW.strand LIMIT NEW.max_concurrent
            ) subquery_for_count) = NEW.max_concurrent THEN
            NEW.next_in_strand := 'f';
          END IF;
        END IF;
        RETURN NEW;
      END;
$$;

alter function delayed_jobs_before_insert_row_tr_fn() owner to canvas;

