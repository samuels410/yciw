create function submission_comment_after_delete_set_last_comment_at__tr_fn() returns trigger
    SET search_path = public
    language plpgsql
as
$$
BEGIN
        UPDATE submissions
        SET last_comment_at = (
           SELECT MAX(submission_comments.created_at) FROM submission_comments
            WHERE submission_comments.submission_id=submissions.id AND
            submission_comments.author_id <> submissions.user_id AND
            submission_comments.draft <> 't' AND
            submission_comments.provisional_grade_id IS NULL
        ) WHERE id = OLD.submission_id;
        RETURN OLD;
      END;
$$;

alter function submission_comment_after_delete_set_last_comment_at__tr_fn() owner to canvas;

