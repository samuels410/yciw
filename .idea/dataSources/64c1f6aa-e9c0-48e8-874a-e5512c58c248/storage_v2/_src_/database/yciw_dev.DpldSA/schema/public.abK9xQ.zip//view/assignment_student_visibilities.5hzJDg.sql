create view assignment_student_visibilities(assignment_id, user_id, course_id) as
SELECT DISTINCT a.id AS assignment_id,
                e.user_id,
                e.course_id
FROM assignments a
         JOIN enrollments e ON e.course_id = a.context_id AND a.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
WHERE (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND COALESCE(a.only_visible_to_overrides, false) = false
UNION
SELECT DISTINCT a.id AS assignment_id,
                e.user_id,
                e.course_id
FROM assignments a
         JOIN enrollments e ON e.course_id = a.context_id AND a.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignment_overrides ao ON a.id = ao.assignment_id AND ao.set_type::text = 'ADHOC'::text
         JOIN assignment_override_students aos ON ao.id = aos.assignment_override_id AND aos.user_id = e.user_id
WHERE ao.workflow_state::text = 'active'::text
  AND aos.workflow_state::text <> 'deleted'::text
  AND (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND a.only_visible_to_overrides = true
UNION
SELECT DISTINCT a.id AS assignment_id,
                e.user_id,
                e.course_id
FROM assignments a
         JOIN enrollments e ON e.course_id = a.context_id AND a.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignment_overrides ao ON a.id = ao.assignment_id AND ao.set_type::text = 'Group'::text
         JOIN groups g ON g.id = ao.set_id
         JOIN group_memberships gm ON gm.group_id = g.id AND gm.user_id = e.user_id
WHERE gm.workflow_state::text <> 'deleted'::text
  AND g.workflow_state::text <> 'deleted'::text
  AND ao.workflow_state::text = 'active'::text
  AND (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND a.only_visible_to_overrides = true
UNION
SELECT DISTINCT a.id AS assignment_id,
                e.user_id,
                e.course_id
FROM assignments a
         JOIN enrollments e ON e.course_id = a.context_id AND a.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignment_overrides ao
              ON e.course_section_id = ao.set_id AND ao.set_type::text = 'CourseSection'::text AND
                 ao.assignment_id = a.id
WHERE (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND a.only_visible_to_overrides = true
  AND ao.workflow_state::text = 'active'::text
UNION
SELECT DISTINCT a.id AS assignment_id,
                e.user_id,
                e.course_id
FROM assignments a
         JOIN enrollments e ON e.course_id = a.context_id AND a.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN submissions s ON s.user_id = e.user_id AND s.assignment_id = a.id AND (s.workflow_state::text <> ALL
                                                                                     (ARRAY ['deleted'::character varying, 'unsubmitted'::character varying]::text[]))
WHERE (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND a.only_visible_to_overrides = true;

alter table assignment_student_visibilities
    owner to canvas;

