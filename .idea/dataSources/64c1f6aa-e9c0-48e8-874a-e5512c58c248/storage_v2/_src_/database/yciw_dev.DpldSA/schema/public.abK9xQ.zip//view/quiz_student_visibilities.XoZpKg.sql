create view quiz_student_visibilities(quiz_id, user_id, course_id) as
SELECT DISTINCT q.id AS quiz_id,
                e.user_id,
                e.course_id
FROM quizzes q
         JOIN enrollments e ON e.course_id = q.context_id AND q.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
WHERE (q.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND COALESCE(q.only_visible_to_overrides, false) = false
UNION
SELECT DISTINCT q.id AS quiz_id,
                e.user_id,
                e.course_id
FROM quizzes q
         JOIN enrollments e ON e.course_id = q.context_id AND q.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignment_overrides ao ON q.id = ao.quiz_id AND ao.set_type::text = 'ADHOC'::text
         JOIN assignment_override_students aos ON ao.id = aos.assignment_override_id AND aos.user_id = e.user_id
WHERE ao.workflow_state::text = 'active'::text
  AND aos.workflow_state::text <> 'deleted'::text
  AND (q.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND q.only_visible_to_overrides = true
UNION
SELECT DISTINCT q.id AS quiz_id,
                e.user_id,
                e.course_id
FROM quizzes q
         JOIN enrollments e ON e.course_id = q.context_id AND q.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignment_overrides ao
              ON e.course_section_id = ao.set_id AND ao.set_type::text = 'CourseSection'::text AND ao.quiz_id = q.id
WHERE (q.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND q.only_visible_to_overrides = true
  AND ao.workflow_state::text = 'active'::text
UNION
SELECT DISTINCT q.id AS quiz_id,
                e.user_id,
                e.course_id
FROM quizzes q
         JOIN enrollments e ON e.course_id = q.context_id AND q.context_type::text = 'Course'::text AND
                               (e.type::text = ANY
                                (ARRAY ['StudentEnrollment'::character varying, 'StudentViewEnrollment'::character varying]::text[])) AND
                               (e.workflow_state::text <> ALL
                                (ARRAY ['deleted'::character varying, 'rejected'::character varying, 'inactive'::character varying]::text[]))
         JOIN assignments a ON q.assignment_id = a.id
         JOIN submissions s ON s.user_id = e.user_id AND s.assignment_id = a.id AND s.workflow_state::text <> 'deleted'::text
WHERE (a.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND (q.workflow_state::text <> ALL (ARRAY ['deleted'::character varying, 'unpublished'::character varying]::text[]))
  AND q.only_visible_to_overrides = true;

alter table quiz_student_visibilities
    owner to canvas;

